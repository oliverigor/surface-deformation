var radius = 3;
var height = 480;
var width = 640;
var numberOfPoints = 400;

var circlesPositionArray = [];
var circles = [];
var currentXPosition = 4;
var distanceX = width / numberOfPoints;

var previousMovement = [];

var k2 = 2;
var k1 = 0.01;

var currentPosX;
var currentPosY;
